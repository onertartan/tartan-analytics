"""
Gaussian Mixture Model (GMM) clustering engine.
Independent from UI and Streamlit. Designed for testability and modularity.
"""
from typing import Tuple, List
import numpy as np
import pandas as pd
from sklearn.mixture import GaussianMixture


class GMMEngine:
    """
    A clean Gaussian Mixture clustering engine for tabular data.
    """
    def __init__(self, n_cluster: int, n_init: int = 1, covariance_type: str = "full", random_state: int = 1):
        """
        Parameters
        ----------
        n_clusters (n_components) : int
            Number of mixture components.
        n_init : int
            Number of restarts.
        covariance_type : str
            'full', 'tied', 'diag', or 'spherical'.
        random_state : int
            Random seed for reproducibility.
        """
        self.gmm = GaussianMixture(
            n_components=n_cluster,
            covariance_type=covariance_type,
            n_init=n_init,
            random_state=random_state
        )
    # ------------------------------------------------------------------
    def fit(self, df: pd.DataFrame) -> pd.DataFrame:
        self.gmm.fit(df.values)

        labels = self.gmm.predict(df.values) + 1

        df_out = df.copy()
        df_out["clusters"] = labels
        return df_out


    def get_representatives(self,df: pd.DataFrame) -> List[str]:
        """
        Representative = observation with highest posterior
        probability for each component.
        Assumes df includes 'clusters' column.
        """
        features = df.iloc[:, :-1].values
        labels = df["clusters"].values
        n_clusters = int(labels.max())

        self.gmm.fit(features)
        posterior = self.gmm.predict_proba(features)

        representatives = []
        for k in range(n_clusters):
            idx = np.argmax(posterior[:, k])
            representatives.append(df.index[idx])

        return representatives
    # ------------------------------------------------------------------
    @staticmethod
    def relabel_with_priority(labels: pd.Series, priority_list: List[str]) -> List[int]:
        """
        Optional deterministic label remapping.

        Parameters
        ----------
        labels : pd.Series
            Original labels indexed by province name.
        priority_list : List[str]
            Ordered list of provinces.

        Returns
        -------
        new_labels : List[int]
        """
        mapping = {}
        next_new = 1

        # Priority-based label ordering
        for prov in priority_list:
            old_lbl = labels.loc[prov]
            if old_lbl not in mapping:
                mapping[old_lbl] = next_new
                next_new += 1

        # Remaining clusters in numeric order
        for old_lbl in sorted(set(labels) - set(mapping)):
            mapping[old_lbl] = next_new
            next_new += 1

        return labels.map(mapping).tolist()
